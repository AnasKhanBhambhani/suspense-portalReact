import React from 'react'

const SuspenseReact = () => {
    return (
        <div>
<h1>this is suspense react.....</h1>
        </div>
    )
}

export default SuspenseReact
