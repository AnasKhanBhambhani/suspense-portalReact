import { lazy, Suspense } from 'react';
import Other from './Components/Other.jsx';
const SuspenseReact = lazy(() => import('./Components/SuspenseReact.jsx'));


function App() {

  return (

    <div className='bg-blue-100 flex flex-col justify-center items-center'>
      <h1>this is lazy loading</h1>
      <Suspense fallback={<h1>your site is loading......</h1>}>
        <SuspenseReact />
      </Suspense>
      <Other/>
    </div>
  );
}

export default App;
